Instructions to code your own VLC Lua extension script.
$Id: $

See lua/README.txt for generic documentation about Lua usage in VLC.

Examples: imdb.lua, lastfm.lua, subtitles.lua

TODO :-)

VLC defines a global vlc object with the following members:
All the VLC specific Lua modules are available, even Extension and Dialog.
